'''This script is working in python 3.6 version and will face UnicodeEncode Issues'''

#from __future__ import unicode_literals
import requests
from bs4 import BeautifulSoup
'''we need to save all of the information that we got from website in a csv file so we need to import csv module here'''
import csv


'''Beatifulsoup is a module that will help us to parse data from a website'''
'''Here i passes a url of coreyms website to get all his website data along with embedded youtube video links'''

Source = requests.get('https://coreyms.com/').text # text means it will remove all tags otherwise will get tags in our output

Soup = BeautifulSoup(Source,'lxml') 

#print(Soup.prettify()) # prettify means it will parse our data in a clean and neat format

csv_file=open('coreyms_scraping.csv','w')
csv_writer=csv.writer(csv_file)
csv_writer.writerow(['headline','summary','video_link'])  # inside list we mentioned headernames means in our csv files first row it will print heading of the coloums

for article in Soup.find_all('article'): # find_all methos is used to find all matched data

    #print(article.prettify())

    headline = article.h2.a.text  # trying to extract headline for a video that is available inside of article with h2 tag
    print(headline)

    paragraph = article.find('div',class_='entry-content').p.text    # here we are ussing .p extension that means that we ahve lot of paragraphs inside of header so if we use .p it will return first paragraph
    print(paragraph)

    '''Now we need to grab video link it is available under iframe'''
    '''Below i am going to use src inside ist that means will get src link in list format so that we can split our list to take source id of video'''

    '''some time there is no video for any one our module it will raise error and stops execution to overcome that issue we used try/except block here
       like we can mention our headers and paragraphs as well if it is not in any article '''
    
    try:
        
        video_link=article.find('iframe',class_='youtube-player')['src']
        #print(video_link)

        '''Below i am using split to split our list by using slash'''

        video_list=video_link.split('/')
        #print(video_list)

        '''Now we got our video source in list format we need to mention our video id index so that will grab that id seperately'''

        video_listend=video_list[4]
        #print(video_listend)


        '''Now we need to take only video id and rest everything we dont want so that we are going to split again with our video_listend as below'''

        video_end=video_listend.split('?')
        #print(video_end)

        '''Now we are taking our video id seperately by using index'''

        video_id=video_end[0]
        #print(video_id)

        '''By using that youtube id i need to find youtube link'''

        yt_link='https://youttube.com/watch?v={}'.format(video_id)
    except:

        yt_link='No Video'
        
    print(yt_link)

    # Here i am mentioning \n that means each and every time it gets some space
    
    print('\n')
    
    #csv_writer.writerow([unicode(article).encode("utf-8") for article in Soup.find_all('article')])
    csv_writer.writerow([headline,paragraph,yt_link])

csv_file.close()
